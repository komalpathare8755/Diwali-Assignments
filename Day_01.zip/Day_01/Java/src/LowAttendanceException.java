
public class LowAttendanceException extends Exception {
	public LowAttendanceException(String msg) {
		super(msg);
	}
}
