package com.example.ecommerceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
