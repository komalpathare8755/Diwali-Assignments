package com.demo.DTO;

import java.util.List;

public class OrderRequestDTO {
    public Long customerId;
    public List<OrderItemDTO> items;
}
