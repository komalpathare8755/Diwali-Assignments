package com.demo.DTO;

public class OrderItemDTO {
    public Long productId;
    public Integer quantity;
}
